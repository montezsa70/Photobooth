# PhotoBooth

Minimal B&W photo-booth for Android. Shoots 4 portrait frames with film grain,
stitches them into a paper strip. Save · Share · Print · Archive.
