package com.photobooth.app.imaging

import android.graphics.*
import java.util.Random
import kotlin.math.sqrt
import kotlin.math.roundToInt

object Film {

    fun process(src: Bitmap, rotationDegrees: Int, mirror: Boolean, w: Int = 1080, h: Int = 1440): Bitmap {
        val m = Matrix()
        if (rotationDegrees != 0) m.postRotate(rotationDegrees.toFloat())
        if (mirror) m.postScale(-1f, 1f)
        val oriented = if (m.isIdentity) src else Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)

        val ratio = w.toFloat() / h
        val srcRatio = oriented.width.toFloat() / oriented.height
        val cw: Int; val ch: Int
        if (srcRatio > ratio) { ch = oriented.height; cw = (ch * ratio).toInt() }
        else { cw = oriented.width; ch = (cw / ratio).toInt() }
        val cropped = Bitmap.createBitmap(oriented, (oriented.width - cw) / 2, (oriented.height - ch) / 2, cw, ch)
        val scaled = Bitmap.createScaledBitmap(cropped, w, h, true)

        val px = IntArray(w * h)
        scaled.getPixels(px, 0, w, 0, 0, w, h)
        val rnd = Random()
        val cx = w / 2f; val cy = h / 2f
        val maxD = sqrt(cx * cx + cy * cy)

        for (i in px.indices) {
            val c = px[i]
            val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
            var l = 0.299f * r + 0.587f * g + 0.114f * b
            l = (l - 128f) * 1.12f + 132f
            val dx = (i % w) - cx; val dy = (i / w) - cy
            val d = sqrt(dx * dx + dy * dy) / maxD
            l *= 1f - 0.16f * d * d * d
            l += (rnd.nextGaussian() * 11.0).toFloat()
            val v = l.roundToInt().coerceIn(0, 255)
            px[i] = (255 shl 24) or (v shl 16) or (v shl 8) or v
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)

        if (scaled !== cropped) scaled.recycle()
        if (cropped !== oriented) cropped.recycle()
        if (oriented !== src) oriented.recycle()
        return out
    }

    fun stitch(frames: List<Bitmap>, label: String, date: String): Bitmap {
        val fw = 690; val fh = 920; val pad = 32; val gap = 24; val footer = 130
        val w = fw + pad * 2
        val h = pad + frames.size * fh + (frames.size - 1) * gap + footer + pad
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(0xFFFBFAF8.toInt())

        frames.forEachIndexed { i, f ->
            val s = Bitmap.createScaledBitmap(f, fw, fh, true)
            c.drawBitmap(s, pad.toFloat(), (pad + i * (fh + gap)).toFloat(), null)
            if (s !== f) s.recycle()
        }

        val baseY = pad + frames.size * fh + (frames.size - 1) * gap
        val ink = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFF141414.toInt(); textSize = 26f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            letterSpacing = 0.32f
        }
        val muted = Paint(ink).apply { color = 0xFFA9A59E.toInt(); textSize = 22f; letterSpacing = 0.18f }
        val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF141414.toInt() }

        c.drawCircle(pad + 7f, baseY + 62f, 7f, dot)
        c.drawText(label, pad + 28f, baseY + 70f, ink)
        c.drawText(date, pad + 28f, baseY + 104f, muted)
        muted.textAlign = Paint.Align.RIGHT
        c.drawText("B&W · GRAIN", (w - pad).toFloat(), baseY + 70f, muted)
        return bmp
    }

    fun decodeSampled(path: String, req: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var s = 1
        while (bounds.outWidth / (s * 2) >= req || bounds.outHeight / (s * 2) >= req) s *= 2
        return BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s })
    }
}
