package com.photobooth.app.ui

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.camera.core.ImageCapture
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.photobooth.app.camera.cameraProvider
import com.photobooth.app.camera.captureBitmap
import com.photobooth.app.camera.selector
import com.photobooth.app.data.StripStore
import com.photobooth.app.imaging.Film
import com.photobooth.app.ui.theme.PB
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private data class Frame(val file: File, val thumb: Bitmap)

@Composable
fun CaptureScreen(facing: Int, store: StripStore, onClose: () -> Unit, onView: (String) -> Unit) {
    SystemBars(light = false)
    BackHandler(onBack = onClose)
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current

    val executor = remember { Executors.newSingleThreadExecutor() }
    val imageCapture = remember {
        ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
    }
    val previewView = remember {
        PreviewView(context).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
    }
    val mono = remember { ColorMatrix().apply { setToSaturation(0f) } }
    var provider by remember { mutableStateOf<ProcessCameraProvider?>(null) }

    val frames = remember { mutableStateListOf<Frame>() }
    var countdown by remember { mutableIntStateOf(0) }
    var capturing by remember { mutableStateOf(false) }
    var done by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var stripPath by remember { mutableStateOf<String?>(null) }
    val flash = remember { Animatable(0f) }

    LaunchedEffect(Unit) { provider = cameraProvider(context) }

    DisposableEffect(provider) {
        val p = provider
        if (p != null) {
            p.unbindAll()
            val preview = Preview.Builder().build()
            preview.setSurfaceProvider(previewView.surfaceProvider)
            p.bindToLifecycle(owner, selector(facing), preview, imageCapture)
        }
        val window = (context as Activity).window
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            provider?.unbindAll()
            executor.shutdown()
        }
    }

    LaunchedEffect(provider) {
        if (provider == null) return@LaunchedEffect
        store.clearSession()
        delay(1100)
        try {
            repeat(4) { idx ->
                for (c in 3 downTo 1) { countdown = c; delay(800) }
                countdown = 0
                capturing = true
                val (raw, rotation) = imageCapture.captureBitmap(executor)
                flash.snapTo(0.9f)
                launch { flash.animateTo(0f, tween(450)) }
                val bmp = withContext(Dispatchers.Default) { Film.process(raw, rotation, mirror = facing == 1) }
                raw.recycle()
                val f = File(store.sessionDir(), "frame_$idx.jpg")
                withContext(Dispatchers.IO) { FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) } }
                frames.add(Frame(f, Bitmap.createScaledBitmap(bmp, 180, 240, true)))
                bmp.recycle()
                capturing = false
                delay(650)
            }
            done = true
            val strip = withContext(Dispatchers.Default) {
                val full = frames.map { BitmapFactory.decodeFile(it.file.absolutePath) }
                val date = SimpleDateFormat("dd MMM yyyy · HH:mm", Locale.US).format(Date())
                Film.stitch(full, "PHOTO BOOTH", date).also { full.forEach(Bitmap::recycle) }
            }
            val out = withContext(Dispatchers.IO) { store.save(strip) }
            strip.recycle()
            stripPath = out.absolutePath
            store.clearSession()
        } catch (e: Exception) {
            error = e.message ?: "Camera error"
        }
    }

    val status = when {
        error != null -> "ERROR"
        done -> "COMPLETE"
        capturing -> "SHOOTING"
        else -> "READY"
    }
    val sub = when {
        error != null -> error!!
        done -> "Looking good."
        capturing -> "Hold…"
        countdown > 0 -> "Keep still"
        else -> "Get ready"
    }

    Box(Modifier.fillMaxSize().background(PB.Dark)) {
        AndroidView(
            factory = { previewView },
            modifier = Modifier.fillMaxSize().graphicsLayer { colorFilter = ColorFilter.colorMatrix(mono) }
        )
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.30f)))
        GrainOverlay(Modifier.fillMaxSize(), alpha = 0.05f)

        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            CircleButton(
                PBIcons.Close, "Close", onClose,
                modifier = Modifier.padding(20.dp), size = 42.dp, iconSize = 18.dp,
                container = Color.White.copy(alpha = 0.14f), tint = PB.OnDark
            )

            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier.fillMaxHeight(0.72f).aspectRatio(0.64f)
                            .border(1.2.dp, Color.White.copy(alpha = 0.85f), RoundedCornerShape(50)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(5.dp).clip(CircleShape).background(PB.OnDark))
                                Spacer(Modifier.width(7.dp))
                                Text(status, fontSize = 10.sp, letterSpacing = 2.2.sp,
                                    color = Color.White.copy(alpha = 0.8f), fontWeight = FontWeight.Medium)
                            }
                            Spacer(Modifier.height(8.dp))
                            when {
                                done -> Icon(PBIcons.Check, null, Modifier.size(56.dp), PB.OnDark)
                                capturing -> Text("…", fontSize = 72.sp, color = PB.OnDark)
                                countdown > 0 -> Text(
                                    countdown.toString(), fontSize = 96.sp, fontWeight = FontWeight.Light,
                                    color = PB.OnDark, letterSpacing = (-2).sp
                                )
                                error != null -> Text("!", fontSize = 96.sp, fontWeight = FontWeight.Light, color = PB.OnDark)
                                else -> Text("4", fontSize = 96.sp, fontWeight = FontWeight.Light,
                                    color = Color.White.copy(alpha = 0.35f))
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(sub, fontSize = 12.sp, color = Color.White.copy(alpha = 0.75f))
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                    Row(Modifier.width(200.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        repeat(4) { i ->
                            Box(
                                Modifier.weight(1f).height(3.dp).clip(RoundedCornerShape(2.dp))
                                    .background(if (i < frames.size) PB.OnDark else Color.White.copy(alpha = 0.22f))
                            )
                        }
                    }
                }
            }

            Column(Modifier.navigationBarsPadding().padding(horizontal = 20.dp, vertical = 16.dp)) {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
                        .background(PB.DarkCard).padding(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    repeat(4) { i ->
                        val fr = frames.getOrNull(i)
                        Box(
                            Modifier.weight(1f).aspectRatio(3f / 4f)
                                .clip(RoundedCornerShape(14.dp)).background(PB.DarkSlot),
                            contentAlignment = Alignment.Center
                        ) {
                            if (fr != null) {
                                Image(fr.thumb.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                            } else {
                                Text("0${i + 1}", fontSize = 11.sp, color = Color.White.copy(alpha = 0.25f))
                            }
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                    Text(
                        "${frames.size} photo${if (frames.size == 1) "" else "s"}",
                        fontSize = 13.sp, color = PB.OnDarkMuted
                    )
                    PillButton(
                        "View", { stripPath?.let(onView) },
                        enabled = stripPath != null,
                        container = PB.OnDark, content = PB.Ink,
                        trailing = PBIcons.ChevronRight
                    )
                }
            }
        }

        if (flash.value > 0f) Box(Modifier.fillMaxSize().background(Color.White.copy(alpha = flash.value)))
    }
}
