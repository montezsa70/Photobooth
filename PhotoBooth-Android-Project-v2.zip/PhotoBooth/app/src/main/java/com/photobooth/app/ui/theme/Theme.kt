package com.photobooth.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object PB {
    val Paper = Color(0xFFF3F1ED)
    val Card = Color(0xFFFFFFFF)
    val Ink = Color(0xFF141414)
    val Muted = Color(0xFFA9A59E)
    val Faint = Color(0xFFDEDBD5)

    val Dark = Color(0xFF161616)
    val DarkCard = Color(0xFF222222)
    val DarkSlot = Color(0xFF2C2C2C)
    val OnDark = Color(0xFFF5F5F3)
    val OnDarkMuted = Color(0xFF9A9A98)
}

private val AppTypography = Typography(
    displayLarge = TextStyle(
        fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold,
        fontSize = 38.sp, lineHeight = 41.sp, letterSpacing = (-0.8).sp
    ),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 14.sp, lineHeight = 20.sp),
    labelSmall = TextStyle(
        fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium,
        fontSize = 11.sp, letterSpacing = 1.6.sp
    )
)

@Composable
fun PhotoBoothTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = PB.Ink, onPrimary = PB.Card,
            background = PB.Paper, onBackground = PB.Ink,
            surface = PB.Paper, onSurface = PB.Ink,
            surfaceVariant = PB.Card, onSurfaceVariant = PB.Ink,
            outline = PB.Faint
        ),
        typography = AppTypography,
        content = content
    )
}
