package com.photobooth.app.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.photobooth.app.camera.cameraProvider
import com.photobooth.app.camera.selector
import com.photobooth.app.ui.theme.PB

@Composable
fun HomeScreen(onStart: (Int) -> Unit, onGallery: () -> Unit, onPrints: () -> Unit) {
    SystemBars(light = true)
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current

    var facing by rememberSaveable { mutableIntStateOf(1) }
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    var pendingStart by remember { mutableStateOf(false) }
    var provider by remember { mutableStateOf<ProcessCameraProvider?>(null) }
    val mono = remember { ColorMatrix().apply { setToSaturation(0f) } }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        granted = ok
        if (ok && pendingStart) { pendingStart = false; onStart(facing) }
    }

    LaunchedEffect(Unit) { provider = cameraProvider(context) }

    val previewView = remember {
        PreviewView(context).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
    }

    DisposableEffect(provider, facing, granted) {
        val p = provider
        if (p != null && granted) {
            p.unbindAll()
            val preview = Preview.Builder().build()
            preview.setSurfaceProvider(previewView.surfaceProvider)
            p.bindToLifecycle(owner, selector(facing), preview)
        }
        onDispose { provider?.unbindAll() }
    }

    Column(
        Modifier.fillMaxSize().background(PB.Paper).statusBarsPadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 24.dp)
    ) {
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            BrandTag("Photo Booth")
            Box(Modifier.size(36.dp).clip(CircleShape).background(PB.Card), contentAlignment = Alignment.Center) {
                Icon(PBIcons.User, null, Modifier.size(17.dp), PB.Ink)
            }
        }
        Spacer(Modifier.height(30.dp))
        Text(
            buildAnnotatedString {
                withStyle(SpanStyle(color = PB.Ink)) { append("Make
your moment
") }
                withStyle(SpanStyle(color = PB.Muted)) { append("count") }
            },
            style = MaterialTheme.typography.displayLarge
        )
        Spacer(Modifier.height(26.dp))

        Box(Modifier.fillMaxWidth()) {
            Box(
                Modifier.fillMaxWidth().aspectRatio(3f / 4f)
                    .clip(RoundedCornerShape(26.dp)).background(PB.Faint)
            ) {
                if (granted && provider != null) {
                    AndroidView(
                        factory = { previewView },
                        modifier = Modifier.fillMaxSize().graphicsLayer { colorFilter = ColorFilter.colorMatrix(mono) }
                    )
                } else {
                    Column(
                        Modifier.align(Alignment.Center),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(PBIcons.Camera, null, Modifier.size(28.dp), PB.Muted)
                        Spacer(Modifier.height(12.dp))
                        Text("Camera access needed", fontSize = 13.sp, color = PB.Muted)
                        Spacer(Modifier.height(16.dp))
                        PillButton("Allow camera", { launcher.launch(Manifest.permission.CAMERA) })
                    }
                }
                Box(
                    Modifier.align(Alignment.TopStart).padding(14.dp)
                        .clip(RoundedCornerShape(9.dp)).background(Color.Black.copy(alpha = 0.35f))
                        .padding(horizontal = 9.dp, vertical = 5.dp)
                ) { Text("3:4", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Medium) }

                CircleButton(
                    PBIcons.Flip, "Flip camera",
                    onClick = { facing = 1 - facing },
                    modifier = Modifier.align(Alignment.TopEnd).padding(12.dp),
                    size = 36.dp, iconSize = 17.dp,
                    container = Color.Black.copy(alpha = 0.35f), tint = Color.White,
                    enabled = granted
                )
            }
            Box(
                Modifier.align(Alignment.BottomCenter).offset(y = 36.dp).size(88.dp)
                    .clip(CircleShape).background(PB.Card)
                    .clickable {
                        if (granted) onStart(facing)
                        else { pendingStart = true; launcher.launch(Manifest.permission.CAMERA) }
                    },
                contentAlignment = Alignment.Center
            ) {
                Box(Modifier.size(66.dp).clip(CircleShape).background(PB.Ink), contentAlignment = Alignment.Center) {
                    Icon(PBIcons.Camera, "Start", Modifier.size(24.dp), PB.Card)
                }
            }
        }
        Spacer(Modifier.height(64.dp))

        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onGallery)) {
                Box(Modifier.size(52.dp).clip(CircleShape).background(PB.Card), contentAlignment = Alignment.Center) {
                    Icon(PBIcons.Photo, null, Modifier.size(20.dp), PB.Ink)
                }
                Spacer(Modifier.height(8.dp))
                Text("Gallery", fontSize = 12.sp, color = PB.Ink)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onPrints)) {
                Box(Modifier.size(52.dp).clip(CircleShape).background(PB.Card), contentAlignment = Alignment.Center) {
                    Icon(PBIcons.Sparkle, null, Modifier.size(20.dp), PB.Ink)
                }
                Spacer(Modifier.height(8.dp))
                Text("Prints", fontSize = 12.sp, color = PB.Ink)
            }
        }
        Spacer(Modifier.height(24.dp))
        Spacer(Modifier.navigationBarsPadding())
    }
}
