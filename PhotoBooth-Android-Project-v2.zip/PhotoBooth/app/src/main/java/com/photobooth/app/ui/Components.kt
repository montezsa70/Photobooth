package com.photobooth.app.ui

import android.app.Activity
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowInsetsControllerCompat
import com.photobooth.app.ui.theme.PB

@Composable
fun SystemBars(light: Boolean) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            WindowInsetsControllerCompat(window, view).apply {
                isAppearanceLightStatusBars = light
                isAppearanceLightNavigationBars = light
            }
        }
    }
}

@Composable
fun BrandTag(text: String, color: androidx.compose.ui.graphics.Color = PB.Ink) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(6.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(8.dp))
        Text(
            text.uppercase(), style = MaterialTheme.typography.labelSmall,
            color = color, fontWeight = FontWeight.Medium, letterSpacing = 1.8.sp
        )
    }
}

@Composable
fun CircleButton(
    icon: ImageVector, desc: String?, onClick: () -> Unit,
    modifier: Modifier = Modifier, size: Dp = 48.dp, iconSize: Dp = 20.dp,
    container: androidx.compose.ui.graphics.Color = PB.Card,
    tint: androidx.compose.ui.graphics.Color = PB.Ink, enabled: Boolean = true
) {
    Box(
        modifier.size(size).clip(CircleShape).background(container)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, desc, Modifier.size(iconSize), tint) }
}

@Composable
fun PillButton(
    text: String, onClick: () -> Unit, modifier: Modifier = Modifier,
    enabled: Boolean = true,
    container: androidx.compose.ui.graphics.Color = PB.Ink,
    content: androidx.compose.ui.graphics.Color = PB.Card,
    leading: ImageVector? = null, trailing: ImageVector? = null
) {
    val bg = if (enabled) container else container.copy(alpha = 0.30f)
    val fg = if (enabled) content else content.copy(alpha = 0.6f)
    Row(
        modifier.clip(RoundedCornerShape(50)).background(bg)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        if (leading != null) { Icon(leading, null, Modifier.size(16.dp), fg); Spacer(Modifier.width(8.dp)) }
        Text(text, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = fg)
        if (trailing != null) { Spacer(Modifier.width(6.dp)); Icon(trailing, null, Modifier.size(15.dp), fg) }
    }
}

@Composable
fun GrainOverlay(modifier: Modifier = Modifier, alpha: Float = 0.06f) {
    val noise = remember {
        val b = android.graphics.Bitmap.createBitmap(160, 160, android.graphics.Bitmap.Config.ARGB_8888)
        val r = java.util.Random(7)
        val px = IntArray(160 * 160) {
            val v = r.nextInt(256)
            (255 shl 24) or (v shl 16) or (v shl 8) or v
        }
        b.setPixels(px, 0, 160, 0, 0, 160, 160)
        b.asImageBitmap()
    }
    val brush = remember(noise) { ShaderBrush(ImageShader(noise, TileMode.Repeated, TileMode.Repeated)) }
    Canvas(modifier) { drawRect(brush = brush, alpha = alpha) }
}
