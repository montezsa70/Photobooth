package com.photobooth.app.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.photobooth.app.data.StripStore
import com.photobooth.app.ui.theme.PB
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ResultScreen(path: String, store: StripStore, onBack: () -> Unit, onRetake: () -> Unit, onDeleted: () -> Unit) {
    SystemBars(light = true)
    val scope = rememberCoroutineScope()
    val file = remember(path) { File(path) }
    val bmp by produceState<Bitmap?>(null, path) {
        value = withContext(Dispatchers.IO) { BitmapFactory.decodeFile(path) }
    }
    var saved by remember(path) { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().background(PB.Paper).statusBarsPadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            BrandTag("Your strip")
            CircleButton(PBIcons.Back, "Back", onBack, size = 42.dp, iconSize = 18.dp)
        }
        Spacer(Modifier.height(26.dp))
        Text("Fresh off
the booth.", style = MaterialTheme.typography.displayLarge, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Text("4 frames · black & white · grain", fontSize = 13.sp, color = PB.Muted, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(26.dp))

        val b = bmp
        if (b != null) {
            Image(
                b.asImageBitmap(), "Photo strip",
                Modifier.fillMaxWidth(0.62f)
                    .shadow(18.dp, RoundedCornerShape(8.dp))
                    .clip(RoundedCornerShape(8.dp)),
                contentScale = ContentScale.Fit
            )
        } else {
            Box(Modifier.fillMaxWidth().height(360.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(Modifier.size(26.dp), color = PB.Ink, strokeWidth = 2.dp)
            }
        }
        Spacer(Modifier.height(30.dp))

        PillButton(
            if (saved) "Saved to Photos" else "Save to Photos",
            onClick = {
                scope.launch {
                    withContext(Dispatchers.IO) { store.export(file) }
                    saved = true
                }
            },
            modifier = Modifier.fillMaxWidth(),
            leading = if (saved) PBIcons.Check else PBIcons.Download
        )
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            CircleButton(PBIcons.Share, "Share", { store.share(file) }, size = 52.dp)
            CircleButton(PBIcons.Print, "Print", { bmp?.let { store.print(it) } }, size = 52.dp)
            CircleButton(PBIcons.Trash, "Delete", {
                scope.launch {
                    withContext(Dispatchers.IO) { file.delete() }
                    onDeleted()
                }
            }, size = 52.dp)
        }
        Spacer(Modifier.height(18.dp))
        Text(
            "Start a new strip", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = PB.Muted,
            modifier = Modifier.clickable(onClick = onRetake).padding(8.dp)
        )
        Spacer(Modifier.height(20.dp))
        Spacer(Modifier.navigationBarsPadding())
    }
}
