package com.photobooth.app.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.photobooth.app.data.StripStore
import com.photobooth.app.imaging.Film
import com.photobooth.app.ui.theme.PB
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun GalleryScreen(store: StripStore, onBack: () -> Unit, onOpen: (File) -> Unit, onStart: () -> Unit) {
    SystemBars(light = true)
    val files by produceState<List<File>>(emptyList()) {
        value = withContext(Dispatchers.IO) { store.list() }
    }

    Column(Modifier.fillMaxSize().background(PB.Paper).statusBarsPadding().padding(horizontal = 24.dp)) {
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            BrandTag("Gallery")
            CircleButton(PBIcons.Back, "Back", onBack, size = 42.dp, iconSize = 18.dp)
        }
        Spacer(Modifier.height(26.dp))
        Text("Your prints.", style = MaterialTheme.typography.displayLarge)
        Spacer(Modifier.height(8.dp))
        Text("${files.size} strip${if (files.size == 1) "" else "s"}", fontSize = 13.sp, color = PB.Muted)
        Spacer(Modifier.height(24.dp))

        if (files.isEmpty()) {
            Column(
                Modifier.fillMaxSize().navigationBarsPadding(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(PBIcons.Sparkle, null, Modifier.size(28.dp), PB.Muted)
                Spacer(Modifier.height(14.dp))
                Text("Nothing here yet.", fontSize = 15.sp, color = PB.Ink)
                Spacer(Modifier.height(4.dp))
                Text("Make your moment count.", fontSize = 13.sp, color = PB.Muted)
                Spacer(Modifier.height(22.dp))
                PillButton("Start a strip", onStart)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(bottom = 24.dp),
                modifier = Modifier.navigationBarsPadding()
            ) {
                items(files, key = { it.absolutePath }) { f ->
                    val thumb by produceState<Bitmap?>(null, f) {
                        value = withContext(Dispatchers.IO) { Film.decodeSampled(f.absolutePath, 400) }
                    }
                    val t = thumb
                    if (t != null) {
                        Image(
                            t.asImageBitmap(), "Strip",
                            Modifier.fillMaxWidth()
                                .shadow(10.dp, RoundedCornerShape(10.dp))
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { onOpen(f) },
                            contentScale = ContentScale.Fit
                        )
                    } else {
                        Box(
                            Modifier.fillMaxWidth().aspectRatio(0.19f)
                                .clip(RoundedCornerShape(10.dp)).background(PB.Faint)
                                .clickable { onOpen(f) }
                        )
                    }
                }
            }
        }
    }
}
