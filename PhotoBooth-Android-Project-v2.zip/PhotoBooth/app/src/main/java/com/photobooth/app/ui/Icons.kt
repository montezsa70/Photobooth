package com.photobooth.app.ui

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathBuilder
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

private fun icon(name: String, block: PathBuilder.() -> Unit): ImageVector =
    ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f).apply {
        path(
            stroke = SolidColor(Color.Black), strokeLineWidth = 1.7f,
            strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round,
            pathBuilder = block
        )
    }.build()

object PBIcons {
    val Camera = icon("camera") {
        addRoundRect(RoundRect(3f, 7.2f, 21f, 19.8f, CornerRadius(3.2f, 3.2f)))
        moveTo(8.8f, 7.2f); lineTo(10.1f, 4.9f); lineTo(13.9f, 4.9f); lineTo(15.2f, 7.2f)
        addOval(Rect(8.7f, 10.4f, 15.3f, 17f))
    }
    val Flip = icon("flip") {
        moveTo(20f, 12f); arcTo(8f, 8f, 0f, true, true, 17.66f, 6.34f)
        moveTo(17.66f, 2.6f); lineTo(17.66f, 6.34f); lineTo(21.4f, 6.34f)
    }
    val Close = icon("close") {
        moveTo(6.5f, 6.5f); lineTo(17.5f, 17.5f)
        moveTo(17.5f, 6.5f); lineTo(6.5f, 17.5f)
    }
    val Photo = icon("photo") {
        addRoundRect(RoundRect(3.4f, 4.4f, 20.6f, 19.6f, CornerRadius(3f, 3f)))
        addOval(Rect(7.4f, 8f, 10.6f, 11.2f))
        moveTo(4.2f, 16.8f); lineTo(9.3f, 11.7f); lineTo(13.4f, 15.8f)
        lineTo(16.2f, 13f); lineTo(19.8f, 16.6f)
    }
    val Sparkle = icon("sparkle") {
        moveTo(12f, 3.2f)
        curveTo(12.7f, 8.2f, 13.8f, 9.3f, 20.8f, 12f)
        curveTo(13.8f, 14.7f, 12.7f, 15.8f, 12f, 20.8f)
        curveTo(11.3f, 15.8f, 10.2f, 14.7f, 3.2f, 12f)
        curveTo(10.2f, 9.3f, 11.3f, 8.2f, 12f, 3.2f)
        close()
    }
    val Share = icon("share") {
        moveTo(12f, 14.6f); lineTo(12f, 3.8f)
        moveTo(8.6f, 7f); lineTo(12f, 3.6f); lineTo(15.4f, 7f)
        moveTo(8.4f, 9.6f); lineTo(6.4f, 9.6f)
        arcTo(2.2f, 2.2f, 0f, false, false, 4.2f, 11.8f)
        lineTo(4.2f, 18.6f)
        arcTo(2.2f, 2.2f, 0f, false, false, 6.4f, 20.8f)
        lineTo(17.6f, 20.8f)
        arcTo(2.2f, 2.2f, 0f, false, false, 19.8f, 18.6f)
        lineTo(19.8f, 11.8f)
        arcTo(2.2f, 2.2f, 0f, false, false, 17.6f, 9.6f)
        lineTo(15.6f, 9.6f)
    }
    val Download = icon("download") {
        moveTo(12f, 3.8f); lineTo(12f, 14.8f)
        moveTo(8.2f, 11.2f); lineTo(12f, 15f); lineTo(15.8f, 11.2f)
        moveTo(5f, 19.6f); lineTo(19f, 19.6f)
    }
    val Trash = icon("trash") {
        moveTo(4.6f, 6.6f); lineTo(19.4f, 6.6f)
        moveTo(9.2f, 6.4f); lineTo(9.2f, 5.2f)
        arcTo(1.6f, 1.6f, 0f, false, true, 10.8f, 3.6f)
        lineTo(13.2f, 3.6f)
        arcTo(1.6f, 1.6f, 0f, false, true, 14.8f, 5.2f)
        lineTo(14.8f, 6.4f)
        moveTo(6.4f, 6.6f); lineTo(7.2f, 18.9f)
        arcTo(2f, 2f, 0f, false, false, 9.2f, 20.8f)
        lineTo(14.8f, 20.8f)
        arcTo(2f, 2f, 0f, false, false, 16.8f, 18.9f)
        lineTo(17.6f, 6.6f)
        moveTo(10.1f, 10.4f); lineTo(10.1f, 16.6f)
        moveTo(13.9f, 10.4f); lineTo(13.9f, 16.6f)
    }
    val Print = icon("print") {
        moveTo(7f, 8.2f); lineTo(7f, 3.6f); lineTo(17f, 3.6f); lineTo(17f, 8.2f)
        addRoundRect(RoundRect(3.8f, 8.2f, 20.2f, 16.4f, CornerRadius(2.2f, 2.2f)))
        moveTo(7f, 13.2f); lineTo(17f, 13.2f); lineTo(17f, 20.4f); lineTo(7f, 20.4f); close()
    }
    val ChevronRight = icon("chevron") {
        moveTo(9.6f, 5.6f); lineTo(16f, 12f); lineTo(9.6f, 18.4f)
    }
    val Back = icon("back") {
        moveTo(14.4f, 5.6f); lineTo(8f, 12f); lineTo(14.4f, 18.4f)
    }
    val Check = icon("check") {
        moveTo(5.2f, 12.6f); lineTo(10f, 17.4f); lineTo(18.8f, 7.2f)
    }
    val User = icon("user") {
        addOval(Rect(8.9f, 5.5f, 15.1f, 11.7f))
        moveTo(5.5f, 19.6f)
        curveTo(5.5f, 16f, 8.4f, 14f, 12f, 14f)
        curveTo(15.6f, 14f, 18.5f, 16f, 18.5f, 19.6f)
    }
}
