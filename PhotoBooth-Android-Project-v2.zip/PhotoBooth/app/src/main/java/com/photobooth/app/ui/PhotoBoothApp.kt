package com.photobooth.app.ui

import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.photobooth.app.data.StripStore

@Composable
fun PhotoBoothApp() {
    val nav = rememberNavController()
    val context = LocalContext.current
    val store = remember { StripStore(context.applicationContext) }

    fun openResult(path: String) = nav.navigate("result/" + Uri.encode(path))

    NavHost(nav, startDestination = "home") {
        composable("home") {
            HomeScreen(
                onStart = { facing -> nav.navigate("capture/$facing") },
                onGallery = { nav.navigate("gallery") },
                onPrints = {
                    val latest = store.list().firstOrNull()
                    if (latest != null) openResult(latest.absolutePath) else nav.navigate("gallery")
                }
            )
        }
        composable("capture/{facing}", listOf(navArgument("facing") { type = NavType.IntType })) { entry ->
            CaptureScreen(
                facing = entry.arguments?.getInt("facing") ?: 1,
                store = store,
                onClose = { nav.popBackStack() },
                onView = { path ->
                    nav.navigate("result/" + Uri.encode(path)) { popUpTo("home") }
                }
            )
        }
        composable("result/{path}") { entry ->
            ResultScreen(
                path = entry.arguments?.getString("path").orEmpty(),
                store = store,
                onBack = { nav.popBackStack() },
                onRetake = { nav.navigate("capture/1") { popUpTo("home") } },
                onDeleted = { nav.popBackStack() }
            )
        }
        composable("gallery") {
            GalleryScreen(
                store = store,
                onBack = { nav.popBackStack() },
                onOpen = { openResult(it.absolutePath) },
                onStart = { nav.navigate("capture/1") }
            )
        }
    }
}
